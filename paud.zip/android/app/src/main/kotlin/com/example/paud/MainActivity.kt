package com.example.paud

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
